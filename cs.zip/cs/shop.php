<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $cake = $_POST["cake"];
    $weight = $_POST["weight"];
    $price = $_POST["price"];

    // Perform server-side validation (similar to client-side validation)
    if (empty($cake) || empty($weight) || empty($price)) {
        echo "All fields are required.";
    } else {
        // Connect to your MySQL database (replace with your database credentials)
        $conn = mysqli_connect("localhost", "root", "", "shop_db");

        // Check the database connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Insert user data into the database
        $sql = "INSERT INTO food (cake, weight, price) VALUES ('$cake', '$weight', '$price')";
        if (mysqli_query($conn, $sql)) {
            // Retrieve the inserted data
            $inserted_id = mysqli_insert_id($conn);
            $sql_select = "SELECT * FROM food WHERE id = $inserted_id";
            $result = mysqli_query($conn, $sql_select);
            $row = mysqli_fetch_assoc($result);

            // Store the retrieved data in the session
            $_SESSION['cart'][] = $row;

            // Display the selected cake details and price
            echo "<h2>Added to Cart!</h2>";
            echo "<p>Cake: $cake</p>";
            echo "<p>Weight: $weight kg</p>";
            echo "<p>Price: Rs. $price</p>";
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
        
        // Close the database connection
        mysqli_close($conn);
    }
}

// Redirect back to shop page
header('Location: shop.html');
?>
