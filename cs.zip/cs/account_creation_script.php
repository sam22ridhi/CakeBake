<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST["name"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    
    // Perform server-side validation (similar to client-side validation)
    if (empty($name) || empty($email) || empty($password)) {
        echo "All fields are required.";
    } else {
        // Connect to your MySQL database (replace with your database credentials)
        $conn = mysqli_connect("localhost", "root", "", "registration_db");
        
        // Check the database connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        
        // Hash the password for security (you should use a stronger hashing method)
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        
        // Insert user data into the database
        $sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$hashed_password')";
        if (mysqli_query($conn, $sql)) {
            // Account created successfully; perform redirection
            header("Location: login.html"); // Replace with the actual URL of your login page
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
        error_reporting(E_ALL);
ini_set('display_errors', 1);

        
        // Close the database connection
        mysqli_close($conn);
    }
}
?>
